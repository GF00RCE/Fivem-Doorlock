fx_version 'cerulean'
game 'gta5'
shared_scripts {
    'Shared/*.lua'
}

client_scripts {
    'Client/*.lua'
}

server_scripts {
    'Server/*.lua'
}

ui_page 'Ui/index.html'

files {
    'Ui/*.html',
    'Ui/*.js',
    'Ui/*.css',
    'Ui/*.otf',
}
