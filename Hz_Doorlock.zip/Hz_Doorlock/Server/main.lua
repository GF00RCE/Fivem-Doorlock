ESX = nil

TriggerEvent('HazardDevelopment:Shared', function(obj) ESX = obj end)
local _doorCache = {}

admins = {
	'steam:1100001478a6468',  --SeYeD AmiR
}

function isAllowedToChange(player)
    local allowed = false
    for i,id in ipairs(admins) do
        for x,pid in ipairs(GetPlayerIdentifiers(player)) do
            if string.lower(pid) == string.lower(id) then
                allowed = true
            end
        end
    end
    return allowed
end

ESX.RegisterServerCallback('Hz_Doorlock:cb:getDoors', function(source,cb) 
    local doors = LoadResourceFile(GetCurrentResourceName(), "Server/Files/Doors.json")
    doors = json.decode(doors)
    cb(doors, _doorCache)
end)

RegisterServerEvent("Hz_Doorlock:server:addDoor", function(_doorCoords, _doorModel, _heading, type, _textCoords, dist, jobs, pin, item)
    local _src = source
    local xPlayer = ESX.GetPlayerFromId(_src)
    if isAllowedToChange(source) then
        local usePin = false
        local useitem = false
        local doors = LoadResourceFile(GetCurrentResourceName(), "Server/Files/Doors.json")
        if pin ~= "" then
            usePin = true
        end
        if item ~= "" then
            useitem = true
        end
        doors = json.decode(doors)
        local tableToIns  = {
            doorCoords = _doorCoords,
            _doorModel = _doorModel,
            _heading = _heading,
            _type = type,
            _textCoords = _textCoords,
            dist = dist,
            jobs = jobs,
            usePin = usePin,
            pin = pin,
            useitem = useitem,
            item = item
        }
        table.insert(doors, tableToIns)
        SaveResourceFile(GetCurrentResourceName(), "Server/Files/Doors.json", json.encode(doors, { indent = true }), -1)
        TriggerClientEvent("Hz_Doorlock:client:refreshDoors", -1, tableToIns)
    end
end)

RegisterServerEvent("Hz_Doorlock:server:addDoubleDoor", function(_doorsDobule, type, _textCoords, dist, jobs, pin, item)
    local _src  = source
    local xPlayer = ESX.GetPlayerFromId(_src)
    if isAllowedToChange(source) then
        local doors = LoadResourceFile(GetCurrentResourceName(), "Server/Files/Doors.json")
        doors = json.decode(doors)
        local useitem = false
        local usePin = false
        if pin ~= "" then
            usePin = true
        end
        if item ~= "" then
            useitem = true
        end
        local tableToIns  = {
            _doorsDouble = _doorsDobule,
            _type = type,
            _textCoords = _textCoords,
            dist = dist,
            jobs = jobs,
            usePin = usePin,
            pin = pin,
            useitem = useitem,
            item = item,
        }
        table.insert(doors, tableToIns)
        SaveResourceFile(GetCurrentResourceName(), "Server/Files/Doors.json", json.encode(doors, { indent = true }), -1)
        TriggerClientEvent("Hz_Doorlock:client:refreshDoors", -1, tableToIns)
    end
end)

RegisterServerEvent("Hz_Doorlock:server:updateDoor", function(id, type)
    _doorCache[id] = type
    TriggerClientEvent("Hz_Doorlock:client:updateDoorState", -1, id, type)
end)

RegisterServerEvent("Hz_Doorlock:server:syncRemove", function(id)
    local _src  = source
    local xPlayer = ESX.GetPlayerFromId(_src)
    if isAllowedToChange(source) then
        local doors = LoadResourceFile(GetCurrentResourceName(), "Server/Files/Doors.json")
        doors = json.decode(doors)
        table.remove(doors, id)
        SaveResourceFile(GetCurrentResourceName(), "Server/Files/Doors.json", json.encode(doors, { indent = true }), -1)
        TriggerClientEvent("Hz_Doorlock:client:removeGlobDoor", -1, id)
    end
end)

RegisterCommand(Config.commands.CreateDoor, function(source, args)  
    local _src  = source
    local xPlayer = ESX.GetPlayerFromId(_src)
    if isAllowedToChange(source) then
        TriggerClientEvent("Hz_Doorlock:client:setUpDoor", _src)
    else
        TriggerClientEvent('Hz_ShowNotification', _src, '~r~Dont Have Access')
    end 
end, false)

RegisterCommand(Config.commands.RemoveDoor, function(source, args)  
    local _src  = source
    local xPlayer = ESX.GetPlayerFromId(_src)
    if isAllowedToChange(source) then
        TriggerClientEvent("Hz_Doorlock:client:deleteDoor", _src)
    else
        TriggerClientEvent('Hz_ShowNotification', _src, '~r~Dont Have Access')
    end 
end, false)

ESX.RegisterServerCallback('Hz_Doorlock:cb:hasObj', function(source,cb, item) 
    local _src = source
    local xPlayer = ESX.GetPlayerFromId(_src)
    local itemPly = xPlayer.getInventoryItem(item)
    if itemPly and itemPly.count > 0 then
        return cb(true)
    else 
        return cb(false)
    end
end)
